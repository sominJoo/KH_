package database;

public class User {

	private static String res_name;
	private static String res_num;
	private static String res_gps;
	private static String res_time;
	private static String res_id;
	private static String res_pw;
	private static String res_code;

	public static String getRes_name() {
		return res_name;
	}

	public static void setRes_name(String res_name) {
		User.res_name = res_name;
	}

	public static String getRes_num() {
		return res_num;
	}

	public static void setRes_num(String res_num) {
		User.res_num = res_num;
	}

	public static String getRes_gps() {
		return res_gps;
	}

	public static void setRes_gps(String res_gps) {
		User.res_gps = res_gps;
	}

	public static String getRes_time() {
		return res_time;
	}

	public static void setRes_time(String res_time) {
		User.res_time = res_time;
	}

	public static String getRes_id() {
		return res_id;
	}

	public static void setRes_id(String res_id) {
		User.res_id = res_id;
	}

	public static String getRes_pw() {
		return res_pw;
	}

	public static void setRes_pw(String res_pw) {
		User.res_pw = res_pw;
	}

	public static String getRes_code() {
		return res_code;
	}

	public static void setRes_code(String res_code) {
		User.res_code = res_code;
	}

}
